package net.hareesh.crudSpring.service;

import java.util.List;

import net.hareesh.crudSpring.model.Employee;

public interface EmployeeService {

	List<Employee> getAllEmployees();
	void saveEmployee(Employee employee);
	Employee getEmployeeById(int id);
	void deleteEmployeeById(int id);

}
